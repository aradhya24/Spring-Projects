package com.aurionpro.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.TransactionCreateRequest;
import com.aurionpro.dto.TransactionResponse;
import com.aurionpro.service.TransactionService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

	private final TransactionService transactionService;

	// ADMIN and CUSTOMER can create transactions
	@PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
	@PostMapping
	public ResponseEntity<TransactionResponse> createTransaction(@Valid @RequestBody TransactionCreateRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(transactionService.createTransaction(request));
	}

	// ADMIN can view all transactions of any account
	// CUSTOMER can view only their own (service layer should enforce ownership
	// check)
	@PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
	@GetMapping("/account/{accountId}")
	public ResponseEntity<List<TransactionResponse>> getTransactionsByAccount(@PathVariable Long accountId) {
		return ResponseEntity.ok(transactionService.getTransactionsByAccountId(accountId));
	}

	// ADMIN can view all transactions of any customer
	// CUSTOMER can view only their own
	@PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
	@GetMapping("/customer/{customerId}")
	public ResponseEntity<List<TransactionResponse>> getTransactionsByCustomer(@PathVariable Long customerId) {
		return ResponseEntity.ok(transactionService.getTransactionsByCustomerId(customerId));
	}

	// CUSTOMER can view their passbook (all txns for one account)
	// ADMIN can view for any account
	@PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
	@GetMapping("/passbook/{accountId}")
	public ResponseEntity<List<TransactionResponse>> getPassbook(@PathVariable Long accountId) {
		return ResponseEntity.ok(transactionService.getPassbook(accountId));
	}

}
