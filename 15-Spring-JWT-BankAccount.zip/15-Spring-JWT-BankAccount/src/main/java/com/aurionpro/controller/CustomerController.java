package com.aurionpro.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurionpro.dto.AccountCreateRequest;
import com.aurionpro.dto.AccountResponse;
import com.aurionpro.dto.CustomerRequest;
import com.aurionpro.dto.CustomerResponse;
import com.aurionpro.service.CustomerService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

 // Customer registers their details after login
    @PreAuthorize("hasRole('CUSTOMER')")
    @PostMapping("/register")
    public ResponseEntity<CustomerResponse> registerCustomer(@Valid @RequestBody CustomerRequest request) {
        return new ResponseEntity<>(customerService.createCustomer(request), HttpStatus.CREATED);
    }


    // ADMIN , CUSTOMER can update customers
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
    @PatchMapping
    public ResponseEntity<CustomerResponse> patchCustomer(
    		 @RequestBody CustomerRequest request) {
        return ResponseEntity.ok(customerService.updateCustomer( request));
    }


    // ADMIN can delete customers
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> inactivateCustomer(@Valid@PathVariable Long id) {
        return ResponseEntity.ok(customerService.inactivateCustomer(id));
    }
    
 // ADMIN can activate customers
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PatchMapping("/{id}")
    public ResponseEntity<String> activateCustomer(@PathVariable Long id) {
        customerService.activateCustomer(id);
        return ResponseEntity.ok(customerService.activateCustomer(id));
    }

    // ADMIN can fetch any customer
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
    @GetMapping("/{id}")
    public ResponseEntity<CustomerResponse> getCustomerById(@PathVariable Long id) {
        return ResponseEntity.ok(customerService.getCustomerById(id));
    }

    // ADMIN can see all customers
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @GetMapping
    public ResponseEntity<List<CustomerResponse>> getAllCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }

    // Customers can create their own account, Admin can also create
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
    @PostMapping("/{customerId}/accounts")
    public ResponseEntity<AccountResponse> createAccount(@Valid @PathVariable Long customerId,
            @RequestBody AccountCreateRequest request) {
        request.setCustomerId(customerId);
        return ResponseEntity.status(HttpStatus.CREATED).body(customerService.createAccount(request));
    }

    // Customers can fetch only their accounts, Admin can fetch customer accounts
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CUSTOMER')")
    @GetMapping("/{customerId}/accounts")
    public ResponseEntity<List<AccountResponse>> getAccounts(@PathVariable Long customerId) {
        return ResponseEntity.ok(customerService.getAccountsByCustomerId(customerId));
    }
}
