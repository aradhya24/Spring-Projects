package com.aurionpro.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.LoginDto;
import com.aurionpro.dto.RegistrationDto;
import com.aurionpro.dto.UserResponse;
import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.exception.UserApiException;
import com.aurionpro.repository.RoleRepo;
import com.aurionpro.repository.UserRepo;
import com.aurionpro.security.JwtTokenProvider;
import com.aurionpro.service.AuthService;
import com.aurionpro.service.EmailService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepo userRepo;
    private final RoleRepo roleRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider tokenProvider;
    private final EmailService emailService;

    // ------------------- Super Admin registration -------------------
    @Override
    public UserResponse register(RegistrationDto registerDto) {
        if (userRepo.existsByUsername(registerDto.getUsername())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User already exists");
        }

        // Prevent multiple super admins
        if ("ROLE_SUPER_ADMIN".equalsIgnoreCase(registerDto.getRole())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST,
                    "Super Admin already exists. Can't create more than one super admin...");
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // Default role
        String roleToAssign = "ROLE_CUSTOMER";

        // Check if logged-in user is SUPER_ADMIN
        boolean isSuperAdmin = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(auth -> auth.toUpperCase().contains("SUPER_ADMIN"));

        // If request is to create an ADMIN
        if ("ROLE_ADMIN".equalsIgnoreCase(registerDto.getRole())) {
            if (!isSuperAdmin) {
                throw new UserApiException(HttpStatus.FORBIDDEN, "Only Super Admin can create Admins");
            }
            roleToAssign = "ROLE_ADMIN";
        }

        // Fetch role entity
        Role userRole = roleRepo.findByRolename(roleToAssign)
                .orElseThrow(() -> new UserApiException(HttpStatus.BAD_REQUEST, "Role does not exist"));

        // Create User
        User user = new User();
        user.setUsername(registerDto.getUsername());
        user.setPassword(passwordEncoder.encode(registerDto.getPassword()));
        user.setRole(userRole);
        user.setIsUserActive(true);

        userRepo.save(user);

        // Send registration email
       // emailService.sendCustomerRegistrationEmail(user.getUsername(), (long) user.getUserId());

        return new UserResponse(user.getUserId(), user.getUsername(), user.getRole().getRolename(), user.getIsUserActive());
    }

    // ------------------- Public Customer registration -------------------
    @Override
    public UserResponse publicRegister(RegistrationDto registerDto) {
        if (userRepo.existsByUsername(registerDto.getUsername())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User already exists");
        }

        // Force CUSTOMER role
        Role customerRole = roleRepo.findByRolename("ROLE_CUSTOMER")
                .orElseThrow(() -> new UserApiException(HttpStatus.BAD_REQUEST, "Customer role does not exist"));

        User user = new User();
        user.setUsername(registerDto.getUsername());
        user.setPassword(passwordEncoder.encode(registerDto.getPassword()));
        user.setRole(customerRole);
        user.setIsUserActive(true);

        userRepo.save(user);

        //emailService.sendCustomerRegistrationEmail(user.getUsername(), (long) user.getUserId());

        return new UserResponse(user.getUserId(), user.getUsername(), user.getRole().getRolename(), user.getIsUserActive());
    }

    // ------------------- Login -------------------
    @Override
    public String login(LoginDto loginDto) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String token = tokenProvider.generateToken(authentication);

            User user = userRepo.findByUsername(loginDto.getUsername())
                                .orElseThrow(() -> new RuntimeException("User not found"));

            // Send email ONLY if:
            // 1. User is ROLE_CUSTOMER
            // 2. User is active
            // 3. Customer profile exists (user.getCustomer() != null)
            if ("ROLE_CUSTOMER".equals(user.getRole().getRolename()) 
                    && user.getIsUserActive() 
                    && user.getCustomer() != null) {

                emailService.sendEmail(
                		 user.getCustomer().getEmailid(),
                    "Login Alert",
                    "Dear Customer,\n\nYou have successfully logged in.\n\nThank you!"
                );
            }

            return token;
        } catch (BadCredentialsException e) {
            throw new UserApiException(HttpStatus.NOT_FOUND, "Username or Password is incorrect");
        }
    }


    // ------------------- Super Admin Methods -------------------
    @Override
    public List<UserResponse> getAllAdmins() {
        Role adminRole = roleRepo.findByRolename("ROLE_ADMIN")
                .orElseThrow(() -> new UserApiException(HttpStatus.BAD_REQUEST, "Admin role not found"));

        return userRepo.findByRole(adminRole).stream()
                .map(u -> new UserResponse(u.getUserId(), u.getUsername(), u.getRole().getRolename(), u.getIsUserActive()))
                .collect(Collectors.toList());
    }

    @Override
    public String inactivateAdmin(int adminId) {
        User admin = userRepo.findById(adminId)
                .orElseThrow(() -> new UserApiException(HttpStatus.NOT_FOUND, "Admin not found"));

        if (!"ROLE_ADMIN".equals(admin.getRole().getRolename())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User is not an admin");
        }

        admin.setIsUserActive(false);
        userRepo.save(admin);
        return "Admin deactivated successfully";
    }

    @Override
    public String activateAdmin(int adminId) {
        User admin = userRepo.findById(adminId)
                .orElseThrow(() -> new UserApiException(HttpStatus.NOT_FOUND, "Admin not found"));

        if (!"ROLE_ADMIN".equals(admin.getRole().getRolename())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User is not an admin");
        }

        admin.setIsUserActive(true);
        userRepo.save(admin);
        return "Admin activated successfully";
    }
}
