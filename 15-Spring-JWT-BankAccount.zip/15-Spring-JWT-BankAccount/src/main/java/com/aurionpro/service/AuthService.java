package com.aurionpro.service;

import java.util.List;

import com.aurionpro.dto.LoginDto;
import com.aurionpro.dto.RegistrationDto;
import com.aurionpro.dto.UserResponse;

public interface AuthService {
	
	UserResponse register(RegistrationDto registration);
    String login(LoginDto loginDto);
    
 // SUPER_ADMIN methods
    List<UserResponse> getAllAdmins();
    String inactivateAdmin(int adminId);
    String activateAdmin(int adminId);

}
