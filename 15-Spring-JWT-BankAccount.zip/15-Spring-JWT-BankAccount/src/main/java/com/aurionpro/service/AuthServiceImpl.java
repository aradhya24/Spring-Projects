package com.aurionpro.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.aurionpro.dto.LoginDto;
import com.aurionpro.dto.RegistrationDto;
import com.aurionpro.dto.UserResponse;
import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.exception.UserApiException;
import com.aurionpro.repository.RoleRepo;
import com.aurionpro.repository.UserRepo;
import com.aurionpro.security.JwtTokenProvider;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor  // Lombok generates constructor for all final fields
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepo userRepo;
    private final RoleRepo roleRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider tokenProvider;
    private final EmailService emailService; // final for constructor injection

    @Override
    public UserResponse register(RegistrationDto registerDto) {
        if (userRepo.existsByUsername(registerDto.getUsername()))
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User already exists");
        
        if ("ROLE_SUPER_ADMIN".equalsIgnoreCase(registerDto.getRole()))
            throw new UserApiException(HttpStatus.BAD_REQUEST, "Super Admin Alread Exists, Can't Create More than one super admin...");

        User user = new User();
        user.setUsername(registerDto.getUsername());
        user.setPassword(passwordEncoder.encode(registerDto.getPassword()));

        Role userRole = roleRepo.findByRolename("ROLE_CUSTOMER")
                .orElseThrow(() -> new UserApiException(HttpStatus.BAD_REQUEST, "Role does not exist"));

        user.setRole(userRole);
        user.setIsUserActive(true); // default active
        userRepo.save(user);

        // Send registration email
        emailService.sendCustomerRegistrationEmail(user.getUsername(), (long)user.getUserId());

        UserResponse dto = new UserResponse();
        dto.setUserId(user.getUserId());
        dto.setUsername(user.getUsername());
        dto.setRole(user.getRole().getRolename());
        return dto;
    }

    @Override
    public String login(LoginDto loginDto) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String token = tokenProvider.generateToken(authentication);

            // Send login alert email for CUSTOMER
            User user = userRepo.findByUsername(loginDto.getUsername())
                                .orElseThrow(() -> new RuntimeException("User not found"));

            if ("ROLE_CUSTOMER".equals(user.getRole().getRolename()) && user.getIsUserActive()) {
                emailService.sendEmail(user.getUsername(),
                                       "Login Alert",
                                       "Dear Customer,\n\nYou have successfully logged in.\n\nThank you!");
            }

            return token;
        } catch (BadCredentialsException e) {
            throw new UserApiException(HttpStatus.NOT_FOUND, "Username or Password is incorrect");
        }
    }
    
    
    
 // ---------------- SUPER_ADMIN METHODS ----------------

    @Override
    public List<UserResponse> getAllAdmins() {
        Role adminRole = roleRepo.findByRolename("ROLE_ADMIN")
                .orElseThrow(() -> new UserApiException(HttpStatus.BAD_REQUEST, "Admin role not found"));

        return userRepo.findByRole(adminRole).stream()
                .map(u -> new UserResponse(u.getUserId(), u.getUsername(), u.getRole().getRolename(),u.getIsUserActive()))
                .collect(Collectors.toList());
    }

    @Override
    public String inactivateAdmin(int adminId) {
        User admin = userRepo.findById(adminId)
                .orElseThrow(() -> new UserApiException(HttpStatus.NOT_FOUND, "Admin not found"));

        if (!"ROLE_ADMIN".equals(admin.getRole().getRolename())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User is not an admin");
        }

        admin.setIsUserActive(false);
        userRepo.save(admin);
        return "Admin deactivated successfully";
    }

    @Override
    public String activateAdmin(int adminId) {
        User admin = userRepo.findById(adminId)
                .orElseThrow(() -> new UserApiException(HttpStatus.NOT_FOUND, "Admin not found"));

        if (!"ROLE_ADMIN".equals(admin.getRole().getRolename())) {
            throw new UserApiException(HttpStatus.BAD_REQUEST, "User is not an admin");
        }

        admin.setIsUserActive(true);
        userRepo.save(admin);
        return "Admin activated successfully";
    }
}

